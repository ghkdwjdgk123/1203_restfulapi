from django.apps import AppConfig


class PracticeConfig(AppConfig):
    name = 'practice'

from django.apps import AppConfig


class PollsConfig(AppConfig):
    name = 'polls'
